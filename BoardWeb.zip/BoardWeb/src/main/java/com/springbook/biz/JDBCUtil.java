package com.springbook.biz;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

public class JDBCUtil {
	

	//getConnection
    public static Connection getConnection() {
    	Connection conn = null;

        try {
        	Class.forName("org.h2.Driver");
        	conn = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
            if (conn != null) {
                System.out.println("DB 연결 성공");
                return conn;
            }
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("DB 연결 실패");
            e.printStackTrace();
        }
        return null;
    }

    //close
    public static void close(PreparedStatement pstmt,Connection conn){
        try {
            if(pstmt!=null){
                pstmt.close();
            }
            if(conn!=null){
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("db자원 반환에 실패했습니다");
            throw new RuntimeException(e);
        }
    }
    public static void close(ResultSet rs,PreparedStatement pstmt,Connection conn){
        try {
            if(rs!=null){
                rs.close();
            }
            if(pstmt!=null){
                pstmt.close();
            }
            if(conn!=null){
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("db자원 반환에 실패했습니다");
            throw new RuntimeException(e);
        }
    }
}