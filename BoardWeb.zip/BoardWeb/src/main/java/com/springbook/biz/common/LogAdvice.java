package com.springbook.biz.common;

import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.util.StopWatch;

public class LogAdvice {
	public void printLog(ProceedingJoinPoint jp) throws Throwable {
		String method = jp.getSignature().getName();
		Object[] args = jp.getArgs();
//		System.out.println("[공통 로그] 비즈니스 로직 수행 전 동작");
//		System.out.println("[사전 처리] "+method+"() 메소드 ARGS 정보 :" + args[0].toString());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		System.out.println("[사전 처리] "+method+"()");
		jp.proceed();
		stopWatch.stop();
		System.out.println("[사후 처리] "+method+"() "+
		"메소드 수행에 걸린 시간 : "+stopWatch.getTotalTimeMillis()+"(ms)초");
	}
}
