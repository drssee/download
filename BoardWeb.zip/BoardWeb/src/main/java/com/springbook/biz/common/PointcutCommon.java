package com.springbook.biz.common;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class PointcutCommon {
	@Pointcut("execution(* polymorphism..*.*(..))")
	public void allPointcut() {}
	
	@Pointcut("execution(* polymorphism..*.*On(..))")
	public void onPointcut() {}
}
