package com.springbook.biz.common;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

@Service
@Aspect
public class AspectTest {
	
	@Around("PointcutCommon.allPointcut()")
	public void printLog(ProceedingJoinPoint pjp) throws Throwable {
		String method = pjp.getSignature().getName();
		Object[] args = pjp.getArgs();
//		System.out.println("[공통 로그] 비즈니스 로직 수행 전 동작");
//		System.out.println("[사전 처리] "+method+"() 메소드 ARGS 정보 :" + args[0].toString());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		System.out.println("[사전 처리] "+method+"()");
		pjp.proceed();
		stopWatch.stop();
		System.out.println("[사후 처리] "+method+"() "+
		"메소드 수행에 걸린 시간 : "+stopWatch.getTotalTimeMillis()+"(ms)초");
	}
}
