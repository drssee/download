package com.springbook.view.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.springbook.biz.board.BoardVO;
import com.springbook.biz.board.impl.BoardDAO;

@WebServlet(name = "action", urlPatterns = { "*.do" })
public class DispatcherServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private HandlerMapping handlerMapping;
	private ViewResolver viewResolver;
	
	


	@Override
	public void init() throws ServletException {
		handlerMapping = new HandlerMapping();
		viewResolver = new ViewResolver();
		viewResolver.setPrefix("./");
		viewResolver.setSuffix(".jsp");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		process(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		process(request,response);
	}
	
	private void process(HttpServletRequest request,HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		String uri = request.getRequestURI();
		
		//해당 servlet으로 오는 요청 url을 가져와서 path추출
		String path = uri.substring(uri.lastIndexOf("/"));
		System.out.println(path);
		
		
		//hm에서 요청 path에 맞는 컨트롤러를 찾아서 반환
		Controller ctrl = handlerMapping.getcontroller(path);
		
		//해당컨트롤러의 로직 수행후 반환되는 뷰이름을 받아옴
		String viewName = ctrl.handleRequest(request, response);
		
		//가져온 viewname을 viewresolver를 거쳐 view 경로를 가져옴
		String view = null;
		if(!viewName.contains(".do")) { 
			view=viewResolver.getView(viewName);
		} else { 
			view = viewName;
		}
		
		//해당 view로 이동
		response.sendRedirect(view);
	}
}
