package polymorphism;

import org.springframework.stereotype.Component;

//@Component("tv")
public class SamsungTV implements TV{
	
	private Speaker speaker;
	private int price;
	
	
	public SamsungTV() {
		System.out.println("-> SamsungTv(1) 객체 생성");
	}
	
	

//	public SamsungTV(Speaker speaker) {
//		System.out.println("-> SamsungTv(2) 객체 생성");
//		this.speaker=speaker;
//	}
//	
//	
//
//
//	public SamsungTV(Speaker speaker, int price) {
//			System.out.println("-> SamsungTv(3) 객체 생성");
//			this.speaker = speaker;
//			this.price = price;
//		}
	
	

//	public void initMethod() {
//		System.out.println("객체 초기화 작업 처리..");
//	}
//	
//	public void destroyMethod() {
//		System.out.println("객체 삭제 전에 처리할 로직 처리..");
//	}

	@Override
	public void powerOn() {
		System.out.println("SansungTV---전원 켠다. "+price); 
	}

	@Override
	public void powerOff() {
		System.out.println("SansungTV---전원 끈다."); 
	}

	@Override
	public void volumeUp() {
//		System.out.println("SansungTV---소리 올린다.");
		speaker.volumeUp();
	}

	@Override
	public void volumeDown() {
//		System.out.println("SansungTV---소리 내린다.");	
		speaker.volumeDown();
	}



	public void setSpeaker(Speaker speaker) {
		this.speaker = speaker;
	}



	public void setPrice(int price) {
		this.price = price;
	}
	
	
	
}

/*
 * public class SamsungTV { public void powerOn() {
 * System.out.println("SansungTV---전원 켠다."); } public void powerOff() {
 * System.out.println("SansungTV---전원 끈다."); } public void volumeUp() {
 * System.out.println("SansungTV---소리 올린다."); } public void volumeDown() {
 * System.out.println("SansungTV---소리 내린다."); } }
 */