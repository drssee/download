package com.springbook.biz.board;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class BoardServiceTest {
	
	ApplicationContext ac = new GenericXmlApplicationContext("applicationContext.xml");
//	BoardService boardService = new BoardServiceImpl(new BoardDAO());
	BoardService boardService = ac.getBean("boardService",BoardService.class);
	
	@Test
	public void insert_deleteTest() {
		BoardVO boardVO = new BoardVO();
		boardVO.setTitle("title");
		boardVO.setWriter("writer");
		boardVO.setContent("content");
		System.out.println(boardVO);
		System.out.println("boardService:"+boardService);
		boardService.insertBoard(boardVO);
		boardVO.setSeq(2);
		BoardVO boardVO1 = boardService.getBoard(boardVO);
		Assert.assertEquals(boardVO.getSeq(), boardVO1.getSeq());
	}
}
