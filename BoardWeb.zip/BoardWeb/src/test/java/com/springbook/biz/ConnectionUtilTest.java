package com.springbook.biz;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class ConnectionUtilTest {
	
	ApplicationContext ac = new GenericXmlApplicationContext("applicationContext.xml");
	
	DataSource dataSource = ac.getBean("dataSource",DataSource.class);
	JDBCUtil jdbcUtil = ac.getBean("jdbcUtil",JDBCUtil.class);
	
	@Test
	public void getConnectionTest() throws SQLException {
		System.out.println(jdbcUtil);
		Connection conn = jdbcUtil.getConnection();
		Assert.assertNotNull(conn);
	}
}
